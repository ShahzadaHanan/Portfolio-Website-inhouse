/* ==========================================================================
   SMOOTH SCROLL (v2 — fixes the freeze bug from the wheel/scroll race)
   A single continuous rAF loop lerps the real scroll position toward a
   wheel-accumulated target. Each frame it also checks whether something
   OTHER than this loop moved the page (keyboard, scrollbar drag, anchor
   link, browser search) by comparing actual scrollY to what we last set —
   if so, it resyncs instead of fighting it. This avoids the previous
   approach's race where our own programmatic scroll was mistaken for a
   user scroll and immediately cancelled, which froze the page.
   Disabled on touch/coarse pointers and when reduced motion is preferred —
   native scrolling is already smooth there.
   ========================================================================== */
(function () {
  "use strict";

  var isFine = window.matchMedia("(pointer: fine) and (hover: hover)").matches;
  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (!isFine || reduced) return;

  var current = window.scrollY;
  var target = window.scrollY;
  var lastSetY = window.scrollY;
  var EASE = 0.1;
  var SYNC_EPSILON = 1.5; // px of drift before we treat it as an external scroll

  function maxScroll() {
    return Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
  }

  function onWheel(e) {
    if (e.target.closest && e.target.closest("[data-native-scroll]")) return;
    e.preventDefault();
    target += e.deltaY;
    target = Math.max(0, Math.min(target, maxScroll()));
  }

  function loop() {
    var actualY = window.scrollY;

    // Something else moved the page since our last write — trust it.
    if (Math.abs(actualY - lastSetY) > SYNC_EPSILON) {
      current = actualY;
      target = actualY;
    }

    if (Math.abs(target - current) > 0.05) {
      current += (target - current) * EASE;
      window.scrollTo(0, current);
      lastSetY = current;
    } else if (current !== target) {
      current = target;
      window.scrollTo(0, current);
      lastSetY = current;
    }

    requestAnimationFrame(loop);
  }

  function onResize() {
    target = Math.min(target, maxScroll());
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.documentElement.classList.add("has-smooth-scroll");
    window.addEventListener("wheel", onWheel, { passive: false });
    window.addEventListener("resize", onResize);
    requestAnimationFrame(loop);
  });
})();
